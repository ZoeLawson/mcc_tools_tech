require.config({
    urlArgs: 't=[TIMESTAMP]'
});